from django.urls import path
from .views import base_views, question_views, answer_views, map_views

app_name = 'prj'

# 빈 url로 요청이 온다면, views 에 index를 연결해줄것이다.
urlpatterns = [
    # base_views.py
    path("", base_views.page, name="page"),
    path("data/",base_views.data,name="data"),
    path("about/",base_views.about,name="about"),
    path("data/",base_views.data,name="data"),
    path('<int:question_id>/',
        base_views.detail, name='detail'),

    # answer_views.py
    path('answer/create/<int:question_id>/',
        answer_views.answer_create, name='answer_create'),
    path('answer/modify/<int:answer_id>/',
        answer_views.answer_modify, name='answer_modify'),
    path('answer/delete/<int:answer_id>/',
        answer_views.answer_delete, name='answer_delete'),
    path('answer/vote/<int:answer_id>/',
        answer_views.answer_vote, name='answer_vote'),

    # question_views.py
    path('question/create/',
        question_views.question_create, name='question_create'),
    path('question/modify/<int:question_id>/',
        question_views.question_modify, name='question_modify'),
    path('question/delete/<int:question_id>/',
        question_views.question_delete, name='question_delete'),
    path('question/vote/<int:question_id>/',
        question_views.question_vote, name='question_vote'),

    # map_views.py
    path('map/',
         map_views.map, name='map'),
    path('map_detail/',
         map_views.map_detail, name='map_detail'),
    path('save_bookmark/',
         map_views.save_bookmark, name='save_bookmark'),
]
